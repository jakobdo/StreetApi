﻿namespace StreetApi.Models
{
    public class StreetName
    {
        public int MunicipalityCode { get; set; }
        public int StreetCode { get; set; }
    }
}
