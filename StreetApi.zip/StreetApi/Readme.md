Mit Rest Api er udviklet i C#, fordi jeg fornemmer det er det prim�re sprog p� denne uddanelse.
Jeg ville m�ske foretr�kke Python, da det er hvad jeg har kodet i de sidste 10-12 �r. :)
Men C# er valget, s� min kode b�rer 100% sikkert pr�g af at kunne v�re lavet bedre og anderledes.
F.eks. ville jeg gerne i Search functionen returnere hele adresser og ikke kun navnet. Men samtlige data er gemt i en database. Valget blev en sqlite, da jeg synes det var "nemmest" og jeg derfor "kun" skulle parse den store text fil en gang.

Jeg m�tte skifte tegns�t, for at f� korrekt ��� med.
Ligeledes skulle nogle datoer konverteres, for at f� dem tilpasset ned i databasen.
Andre p� holdet snakkede om at gemme data i en ren json fil, men jeg havde sv�rt ved at se en ren s�gning i JSON, kunne v�re hurtigere end et opslag i en sqlite.
SQLITE er trods alt lidt mere databasen, end en json fil t�nkte jeg.

Mit program k�res ved at starte projektet og trykke F5. :)

Sk�rmdumps finder i mappen: Screenshots.